package com.example.mylogin_signin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.mylogin_signin.databinding.ActivityLoginBinding;
import com.example.mylogin_signin.databinding.ActivityRegistrationBinding;

import java.time.Year;


public class Registration_Activity extends AppCompatActivity {  //implement onclick listener for date picker ..........

    private ActivityRegistrationBinding binding;

    private RadioButton radioButton;
    private DatePickerDialog datePickerDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_registration_);


      // on click leastener for BirthofDate............
        binding.dateOfbirthID.setOnClickListener(new View.OnClickListener() {

            DatePicker datePicker=new DatePicker(Registration_Activity.this);


            final   int  Year= datePicker.getYear();
            final int  Month= datePicker.getMonth()+1;
            final  int  Day= datePicker.getDayOfMonth();

            @Override
            public void onClick(View v) {

                datePickerDialog=new DatePickerDialog(Registration_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                      binding.dateOfbirthID.setText(Day+"/"+Month+"/"+Year);


                    }
                },Year,Month,Day);
                datePickerDialog.show();
            }
        });
    //..................................

        binding.creatAccountButtonID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //for radio button,,,,male,female........

               int radioid = binding.radioGroupID.getCheckedRadioButtonId();

                radioButton = findViewById(radioid);


               //for get text registration  to profile..........

                Intent intent = new Intent(Registration_Activity.this, Profile_Activity.class);
                intent.putExtra("registraton_Info_First_name", binding.firstNameID.getText().toString());
                intent.putExtra("registraton_Info_Last_name", binding.lastNameID.getText().toString());
                intent.putExtra("registraton_Info_email", binding.EmailID.getText().toString());
                intent.putExtra("registraton_Info_phone", binding.phoneNumberID.getText().toString());
                intent.putExtra("registraton_Info_gender_male_female", radioButton.getText().toString());
                intent.putExtra("birth_Of_Date", binding.dateOfbirthID.getText().toString());

                startActivity(intent);


            }
        });


        //Adding back button in Action bar...continue..
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //.............



    }



    //Adding back button in Action bar
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
    //..............





}
