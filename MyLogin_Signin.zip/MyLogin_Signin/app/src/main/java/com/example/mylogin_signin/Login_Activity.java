package com.example.mylogin_signin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mylogin_signin.databinding.ActivityLoginBinding;

public class Login_Activity extends AppCompatActivity {
    //private Button facebookButton;
//private Button googleButton;
//private Button twitterButton;
//
//private TextView creatAccount;
    private String email = "faisal@gmail.com";
    private String password = "12345678";


    private ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_);



        // Facebook,Google,Twitter loging Button........

        binding.facebookButtonId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login_Activity.this, "API not connected", Toast.LENGTH_SHORT).show();

            }
        });

        binding.googleButtonId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login_Activity.this, "API not connected", Toast.LENGTH_SHORT).show();

            }
        });

        binding.twitterButtonId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login_Activity.this, "API not connected", Toast.LENGTH_SHORT).show();

            }
        });


        //create Account Intent.........

        binding.creatAccountTextID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Login_Activity.this, Registration_Activity.class);
                startActivity(intent);
            }
        });


        //login Intent.........

        binding.creatAccountButtonID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (binding.loginEmailEditTextID.getText().toString().equals(email) &&
                        binding.loginPasswordEditTextID.getText().toString().equals(password)) {

                    Intent intent = new Intent(Login_Activity.this, Profile_Activity.class);
                    startActivity(intent);
                }else
                {
                    Toast.makeText(Login_Activity.this,"Invalid Email or Password",Toast.LENGTH_SHORT).show();
                }



            }
        });


        //Adding logo in action bar.......
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_cash);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        //........................



    }
}
