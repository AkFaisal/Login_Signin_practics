package com.example.mylogin_signin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.mylogin_signin.databinding.ActivityProfileBinding;

public class Profile_Activity extends AppCompatActivity {

    private ActivityProfileBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_profile_);


        binding.profileNameTextID.setText(getIntent().getStringExtra("registraton_Info_First_name"));
        binding.profileLastNameID.setText(getIntent().getStringExtra("registraton_Info_Last_name"));
        binding.profileEmailTextID.setText(getIntent().getStringExtra("registraton_Info_email"));
        binding.profilePhoneTextID.setText(getIntent().getStringExtra("registraton_Info_phone"));
        binding.profileGenderTextID.setText(getIntent().getStringExtra("registraton_Info_gender_male_female"));
        binding.BirthID.setText(getIntent().getStringExtra("birth_Of_Date"));


        //Adding back button in Action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //.............
    }

    //Adding back button in Action bar
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
    //..............



}
